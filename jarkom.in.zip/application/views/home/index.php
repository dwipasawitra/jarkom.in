<p>Selamat datang di layanan JARKOM.IN, layanan pengiriman pesan siar 
    berbasis SMS dan Twitter murah khusus untuk kebutuhan Jarkom (Jejaring Komunikasi)/SMS masal untuk pengiriman pesan
    informasi tentang kegiatan kemahasiswaan/perkuliahan dan kegiatan lainnya</p>
<center>
    <img src="<?php echo base_url('assets/img/jarkomin-arsitektur.png');?>" width="50%"/>
</center>

<p>Layanan ini didirikan atas dasar sulitnya hidup sebagai mahasiswa: harus tahu segala informasi, harus bisa menyebarkan informasi
    penting ke teman lainnya dan mahalnya biaya SMS (walaupun ada BBM, WhatsApp, Line, toh tidak semua mahasiswa menggunakan fitur itu 24x7 bukan? :D)
    Maka dari itu, JARKOM.IN menawarkan layanan pengiriman pesan Jarkom secara murah ke berbagai operator yang dijamin cepat, murah dan sampai di tujuan</p>

<p>Untuk menggunakan JARKOM.IN, anda harus mendaftar. Untuk saat ini, <strong>pendaftaran hanya bisa dilakukan secara tertutup di Laboratorium Arsitektur & Jaringan Komputer (AJK), Jurusan Teknik Informatika, 
        Institut Teknologi Sepuluh Nopember</strong>. Setiap pendaftar akan mendapatkan poin (semacam pulsa) yang bisa dibeli dengan harga berikut (berlaku akumulasi):</p>
<ul>
    <li>100 poin: Rp. 1.000,-</li>
    <li>1000 poin: Rp. 8.000,-</li>
</ul>
<p>Satu poin dapat digunakan untuk mengirim 1 SMS 160 karakter ke seorang penerima.</p>
<p>Apa yang membuat JARKOM.IN berbeda dengan layanan sejenis lainnya?</p>
<ul>
    <li>Pesan terkirim via SMS maupun Twitter dari penerimanya</li>
    <li>Modem yang digunakan untuk mengirim berjumlah 7, dengan operator yang berbeda-beda. SMS akan dikirim via modem dengan operator yang sesuai</li>
    <li>Manajemen kegiatan, pengingat adanya kegiatan dan konfirmasi kehadiran pesertanya</li>
    <li>Pesan dapat dikirimkan via HP pengguna :)</li>
</ul>
<div class="success">
    JARKOM.IN dibuat dalam rangka pelaksanaan Program Kreativitas Mahasiswa-Karsa Cipta (PKM-KC) Dikti 2013 untuk membuat suatu konsep
    layanan pengiriman pesan siar via SMS dan jejaring sosial untuk berbagai kebutuhan. <br/>
    Tim JARKOM.IN terdiri dari: 
    <ul>
        <li>Putu Wiramaswara Widya (Konseptor)</li>
        <li>Herleeyandi Markoni (Pemrogram Aplikasi)</li>
        <li>Dhimas Bagus Pramudya (Pengelola Sistem)</li>
        <li>Benediktus Anindito (Pemrogram Sistem)</li>
        <li>Bahrul Halimi (Sekretaris + Bendahara)</li>
    </ul>
</div>